<div id="footer" class="page-footer">
    <div class="d-flex p-3">
        <span class="text-sm text-muted flex"><?php require "_copyright.php" ?></span>
        <div class="text-sm text-muted">Version 0.0</div>
    </div>
</div>