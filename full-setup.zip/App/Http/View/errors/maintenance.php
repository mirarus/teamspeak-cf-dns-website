<div class="page-content page-container" id="page-content">
    <div class="padding">
        <div class="alert bg-light py-4" role="alert">
            <div class="d-flex">
                <i data-feather="code" width="48" height="48"></i>
                <div class="px-3">
                    <h5 class="alert-heading">Bakım</h5>
                    <p>Endişelenmeyin, en kısa sürede düzelteceğiz.</p>
                </div>
            </div>
        </div>
    </div>
</div>