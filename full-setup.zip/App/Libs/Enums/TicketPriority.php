<?php

namespace App\Libs\Enums;

class TicketPriority
{
	const LOW = ["gd-info", "Düşük"];
	const MIDDLE = ["gd-warning", "Orta"];
	const HIGH = ["gd-danger", "Yüksek"];
}