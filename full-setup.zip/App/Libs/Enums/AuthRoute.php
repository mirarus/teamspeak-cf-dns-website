<?php

namespace App\Libs\Enums;

class AuthRoute
{
	const SIGNIN = "signin";
	const SIGNUP = "signup";
	const LOGOUT = "logout";
}