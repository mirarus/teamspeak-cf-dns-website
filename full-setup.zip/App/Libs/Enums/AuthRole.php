<?php

namespace App\Libs\Enums;

class AuthRole
{
	const USER = "user";
	const ADMIN = "admin";
}